from django.shortcuts import render, HttpResponse,HttpResponseRedirect
from django import forms
from django.core.mail import send_mail, get_connection
from django.conf import settings
def index(request):
    return render(request, 'index.html')

def contact(request):
   return HttpResponse("<h1>this is contact page</h1>")
def services(request):
    return render(request, 'services.html')
def pricing(request):
    return render(request, 'pricing.html')
class ContactForm(forms.Form):
    yourname = forms.CharField(max_length=200, label='Your Name')
    email = forms.EmailField(required=False,label='Your e-mail address')
    subject = forms.CharField(max_length=200)
    message = forms.CharField(widget=forms.Textarea) 
def contact(request):
    submitted = False
    if request.method == 'POST':
      form = ContactForm(request.POST)
      if form.is_valid():
        #cd = form.cleaned_data
        name= request.POST['yourname']
        emailAddress = request.POST['email']
        subject = request.POST['subject'] 
        message =  "Name:"+ " " +name +" "+"\nEmail Address: "+emailAddress+ " " +"\nMessage:"+ " "+request.POST['message']
        from_email =settings.EMAIL_HOST_USER
        to_list = ['syed.shahid.shabir@gmail.com',settings.EMAIL_HOST_USER] 
        send_mail(
            subject,
            message,
            from_email,
            to_list, 
		    fail_silently=True,
        )
        return HttpResponseRedirect('/Queries?submitted=True')
    else:
        form = ContactForm()
        if 'submitted' in request.GET:
            submitted = True
    return render(request, 'contact.html', {'form': form, 'submitted': submitted})